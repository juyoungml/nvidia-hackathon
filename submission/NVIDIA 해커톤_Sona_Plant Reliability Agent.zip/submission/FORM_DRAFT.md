# 온라인 신청서 초안

서비스명: **Plant Reliability Agent** (가칭)
팀명: **Sona**
팀원: 2~5인 구성 및 각 구성원의 개별 신청 확인 필요

## 해결하고자 했던 문제 — 300자 내외

발전소가 계획에 없이 멈추면 손실이 큽니다(Siemens 2024: 글로벌 대기업의 비계획 정지 손실 연 1.4조 달러). 이상이 생기면 엔지니어는 P&ID·로직 다이어그램 같은 도면, 기술 메모(TM), 작업 지시(WO), 트렌드 데이터를 하나씩 대조해 원인을 찾아야 하지만, 자료가 흩어져 있고 계측이 정상처럼 보이는 경우도 많아 판단이 늦어집니다. 게다가 발전소는 보안상 외부 클라우드 AI를 쓰기 어렵습니다. 저희는 현장 안에 설치할 수 있는 모델로 이 첫 조사를 대신하는 에이전트를 만들었습니다.

## 서비스 소개 및 주요 기능 — 500자 내외

Plant Reliability Agent는 두 부분으로 설계했습니다. System 1은 항상 켜져 트렌드 데이터를 감시하다 이상 징후를 알리고(설계 단계, Nemotron Nano 후보), System 2는 이상 신고가 들어오면 조사를 맡습니다(구현·시연). System 2에서는 NVIDIA Nemotron 3 Ultra가 계측, 센서 정의, 과거 신고, 정비 이력, 특정 시간대 조회 등 읽기 전용 도구 6종 중 필요한 자료를 스스로 골라 읽고, 결과를 대조해 다음에 확인할 점검 항목과 이유를 정해진 형식으로 작성합니다. 모든 제안에는 참고한 원본 기록이 연결되어 엔지니어가 클릭 한 번으로 근거를 확인할 수 있습니다. 흐름은 신고 접수 → 신고 이전 자료만 조회 → 근거 달린 점검안 → 엔지니어 검토입니다. 공개 데이터(PreDist v2) 32건 평가에서 Ultra가 작성한 점검안은 모두 실제 조회한 기록만 인용했고(근거 조작 0건), 남은 격차는 API 오류·도구 실수 같은 실행 안정성 문제로 현장 배포와 도구 보완으로 해결할 예정입니다.

## 활용한 핵심 기술 및 AI 모델

- NVIDIA Nemotron 3 Ultra (NVIDIA NIM, `nvidia/nemotron-3-ultra-550b-a55b`): 에이전트의 두뇌. 도구 선택(tool calling), 결과 비교, JSON 스키마 기반 점검안 생성. 모든 데모 실행의 핵심 경로
- NVIDIA NeMo Agent Toolkit 1.8.0: 읽기 도구 6종 등록·실행. 직접 호출과 결과 동일성 확인, 사례 52에서 에이전트가 고른 조회 6회 실행
- NVIDIA OpenShell 0.1.2: 에이전트 격리 실행 환경. 허용된 읽기만 통과하고 그 밖의 읽기·쓰기·외부 통신 차단을 시험 데이터로 확인
- NVIDIA DGX Spark (배포 대상): Ultra 기준 3~4대, Nemotron 3 Super 120B 기준 1대로 추정
- 계획: Nemotron Nano(System 1 상시 감시·재정렬), NeMo Retriever(도면·문서 검색)
- 그 외: Python 3.12, uv, unittest, Ruff, HTML/CSS/JavaScript, matplotlib, GitHub Pages
- 데이터·비교 기준: PreDist v2 공개 지역난방 데이터(CC BY 4.0), Claude Code + Claude Sonnet 5

## 파일 제출 안내

파일 하나, 최대 100 MB. 최종 System2 ZIP에는 코드·공개 데모·발표 슬라이드·설명 Markdown·실행 근거를 함께 넣습니다. README부터 확인할 수 있으며 API 키 없이 저장 실행을 탐색합니다. 실제 API 재실행은 별도 키와 인증이 필요합니다. 이전 PDF·영상은 최신 제출 파일로 사용하지 않습니다.

제출 파일: `submission/NVIDIA 해커톤_Sona_Plant Reliability Agent.zip`. 데모 URL: http://juyoung.site/nvidia-hackathon/ · 저장소: https://github.com/juyoungml/nvidia-hackathon

이 문서는 입력 초안이며 신청 완료가 아닙니다. 개인정보 동의와 각 구성원의 신청은 직접 진행해야 합니다.
